Name:
Reg No:
college name:Sri Ranganathar Institute Of Engineering and Technology
Description:
	 Assignment 1- Portfolio Creation
	 
	 Created my portfolio using HTML,FontAwesome(cdn-used for Icons) and CSS
	 
